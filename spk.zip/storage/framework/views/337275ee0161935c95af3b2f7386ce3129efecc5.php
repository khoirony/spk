

<?php $__env->startSection('container'); ?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Solusi Ideal Positif dan Negatif</h1>
</div>

<div class="container-fluid">
    <table class="table table-striped table-hover">
        <thead>
            <tr>
                <th scope="col">+-</th>
                <th scope="col">Status Bangunan</th>
                <th scope="col">Status Lahan</th>
                <th scope="col">Luas Lantai</th>
                <th scope="col">Jenis Lantai</th>
                <th scope="col">Jenis Dinding</th>
                <th scope="col">Fasilitas BAB</th>
                <th scope="col">Daya Listrik</th>
                <th scope="col">Status Bantuan</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $positifnegatif; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <th scope="row"><?php echo e($pn->name); ?></th>
            <td>
              <?php echo e($pn->status_bangunan); ?>

            </td>
            <td>
              <?php echo e($pn->status_lahan); ?>

            </td>
            <td>
              <?php echo e($pn->luas_lantai); ?></sup>
            </td>
            <td>
              <?php echo e($pn->jenis_lantai); ?>

            </td>
            <td>
              <?php echo e($pn->jenis_dinding); ?>

            </td>
            <td>
              <?php echo e($pn->fas_bab); ?>

            </td>
            <td>
              <?php echo e($pn->daya_listrik); ?>

            </td>
            <td>
              <?php echo e($pn->status_bantuan); ?>

            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table><br>

    <div class="row">
      <div class="col">
        <h3>D+</h3>
        <table class="table table-striped table-hover">
          <thead>
              <tr>
                  <th scope="col">Alternatif</th>
                  <th scope="col">Nilai</th>
              </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $dpositif; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <th scope="row"><?php echo e($dp->name); ?></th>
              <td>
                <?php echo e($dp->nilai); ?>

              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
        <?php echo e($dpositif->links()); ?>

      </div>
      <div class="col">
        <h3>D-</h3>
        <table class="table table-striped table-hover">
          <thead>
              <tr>
                  <th scope="col">Alternatif</th>
                  <th scope="col">Nilai</th>
              </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $dnegatif; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <th scope="row"><?php echo e($dn->name); ?></th>
              <td>
                <?php echo e($dn->nilai); ?>

              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
        <?php echo e($dnegatif->links()); ?>

      </div>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\spk\resources\views/dashboard/solusi/index.blade.php ENDPATH**/ ?>