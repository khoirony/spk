

<?php $__env->startSection('container'); ?>

<div class="p-5">
    <h1 class="text-center">Selamat Datang di
        Sistem Pendukung Keputusan <br>
        Penentuan Kelayakan Penerima <br>
        Bantuan Sosial Tunai
    </h1>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\spk\resources\views/dashboard/index.blade.php ENDPATH**/ ?>