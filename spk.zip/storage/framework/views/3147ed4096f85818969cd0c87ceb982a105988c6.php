

<?php $__env->startSection('container'); ?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Normalisasi Terbobot</h1>
</div>

<div class="container-fluid">
    <table class="table table-striped table-hover">
        <thead>
          <tr>
            <th scope="col">Alternatif</th>
            <th scope="col">Status Bangunan</th>
            <th scope="col">Status Lahan</th>
            <th scope="col">Luas Lantai</th>
            <th scope="col">Jenis Lantai</th>
            <th scope="col">Jenis Dinding</th>
            <th scope="col">Fasilitas BAB</th>
            <th scope="col">Daya Listrik</th>
            <th scope="col">Status Bantuan</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $terbobot; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <th scope="row"><?php echo e($t->name); ?></th>
            <td>
              <?php echo e($t->status_bangunan); ?>

            </td>
            <td>
              <?php echo e($t->status_lahan); ?>

            </td>
            <td>
              <?php echo e($t->luas_lantai); ?></sup>
            </td>
            <td>
              <?php echo e($t->jenis_lantai); ?>

            </td>
            <td>
              <?php echo e($t->jenis_dinding); ?>

            </td>
            <td>
              <?php echo e($t->fas_bab); ?>

            </td>
            <td>
              <?php echo e($t->daya_listrik); ?>

            </td>
            <td>
              <?php echo e($t->status_bantuan); ?>

            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
</div>
<?php echo e($terbobot->links()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\spk\resources\views/dashboard/terbobot/index.blade.php ENDPATH**/ ?>