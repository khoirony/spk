

<?php $__env->startSection('container'); ?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Manage Alternatif</h1> <a href="/tambah" class="btn btn-sm btn-primary">Tambah Data</a>
</div>

<div>
    <table class="table table-striped table-hover">
        <thead>
          <tr>
            <th scope="col">Alternatif</th>
            <th scope="col">Status Bangunan</th>
            <th scope="col">Status Lahan</th>
            <th scope="col">Luas Lantai</th>
            <th scope="col">Jenis Lantai</th>
            <th scope="col">Jenis Dinding</th>
            <th scope="col">Fasilitas BAB</th>
            <th scope="col">Daya Listrik</th>
            <th scope="col">Status Bantuan</th>
            <th scope="col" style="text-align: center;width:90px;">Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $alternatif; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <th scope="row"><?php echo e($a->name); ?></th>
            <td>
              <?php switch($a->status_bangunan):
                case (1): ?>
                  Milik Sendiri <?php break; ?>
                <?php case (2): ?>
                  Kontrakan/Sewa <?php break; ?>
                <?php case (3): ?>
                  Bebas Sewa <?php break; ?>
                <?php case (4): ?>
                  Dinas <?php break; ?>
                <?php case (5): ?>
                  Lainnya <?php break; ?>
                <?php default: ?>
                  -kosong-
              <?php endswitch; ?>
            </td>
            <td>
              <?php switch($a->status_lahan):
                case (1): ?>
                  Milik Sendiri <?php break; ?>
                <?php case (2): ?>
                  Milik Orang lain <?php break; ?>
                <?php case (3): ?>
                  Tanah Negara <?php break; ?>
                <?php case (4): ?>
                  Lainnya <?php break; ?>
                <?php default: ?>
                  -kosong-
              <?php endswitch; ?>
            </td>
            <td>
              <?php echo e($a->luas_lantai); ?> M<sup>2</sup>
            </td>
            <td>
              <?php switch($a->jenis_lantai):
                case (1): ?>
                  Marmer/Granit <?php break; ?>
                <?php case (2): ?>
                  Kermik <?php break; ?>
                <?php case (3): ?>
                  Parket/Vinyl <?php break; ?>
                <?php case (4): ?>
                  Ubin/Tegel <?php break; ?>
                <?php case (5): ?>
                  Kayu Berkualitas Tinggi <?php break; ?>
                <?php case (6): ?>
                  Semen/Bata <?php break; ?>
                <?php case (7): ?>
                  Bambu <?php break; ?>
                <?php case (8): ?>
                  Kayu Berkualitas Rendah <?php break; ?>
                <?php case (9): ?>
                  Tanah <?php break; ?>
                <?php case (10): ?>
                  Lainnya <?php break; ?>
                <?php default: ?>
                  -kosong-
              <?php endswitch; ?>
            </td>
            <td>
              <?php switch($a->jenis_dinding):
                case (1): ?>
                  Tembok <?php break; ?>
                <?php case (2): ?>
                  Plesteran Anyaman Bambu/Kawat <?php break; ?>
                <?php case (3): ?>
                  Kayu <?php break; ?>
                <?php case (4): ?>
                  Anyaman Bambu <?php break; ?>
                <?php case (5): ?>
                  Batang Kayu <?php break; ?>
                <?php case (6): ?>
                  Bambu <?php break; ?>
                <?php case (7): ?>
                  Lainnya <?php break; ?>
                <?php default: ?>
                  -kosong-
              <?php endswitch; ?>
            </td>
            <td>
              <?php switch($a->fas_bab):
                case (1): ?>
                  Sendiri <?php break; ?>
                <?php case (2): ?>
                  Bersama <?php break; ?>
                <?php case (3): ?>
                  Umum <?php break; ?>
                <?php case (4): ?>
                  Tidak Ada <?php break; ?>
                <?php default: ?>
                  -kosong-
              <?php endswitch; ?>
            </td>
            <td>
              <?php switch($a->daya_listrik):
                case (1): ?>
                  450 Watt <?php break; ?>
                <?php case (2): ?>
                  900 Watt <?php break; ?>
                <?php case (3): ?>
                  1300 Watt <?php break; ?>
                <?php case (4): ?>
                  2200 Watt <?php break; ?>
                <?php case (5): ?>
                  >2200 Watt <?php break; ?>
                <?php case (6): ?>
                  Tanpa Meteran <?php break; ?>
                <?php default: ?>
                  -kosong-
              <?php endswitch; ?>
            </td>
            <td>
              <?php switch($a->status_bantuan):
                case (1): ?>
                  Ada <?php break; ?>
                <?php case (2): ?>
                  Tidak <?php break; ?>
                <?php default: ?>
                  -kosong-
              <?php endswitch; ?>
            </td>
            <td>
                <a href="/edit/<?php echo e($a->id); ?>" class="btn btn-sm btn-warning"><span data-feather="edit"></span></a> <a href="/hapus/<?php echo e($a->id); ?>" class="btn btn-sm btn-secondary"><span data-feather="trash-2"></span></a>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
</div>
<?php echo e($alternatif->links()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\spk\resources\views/dashboard/alternatif/index.blade.php ENDPATH**/ ?>