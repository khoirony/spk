

<?php $__env->startSection('container'); ?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Preferensi</h1>
</div>

<div class="container-fluid">
  <table class="table table-striped table-hover">
    <thead>
        <tr>
            <th scope="col">Alternatif</th>
            <th scope="col">Preferensi</th>
            <th scope="col">Rangking</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $preferensi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <th scope="row"><?php echo e($p->name); ?></th>
              <td>
                <?php echo e($p->nilai); ?>

              </td>
              <td>
                <?php echo e($p->rangking); ?>

              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\spk\resources\views/dashboard/preferensi/index.blade.php ENDPATH**/ ?>