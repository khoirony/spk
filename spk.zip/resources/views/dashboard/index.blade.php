@extends('dashboard.layouts.main')

@section('container')

<div class="p-5">
    <h1 class="text-center">Selamat Datang di
        Sistem Pendukung Keputusan <br>
        Penentuan Kelayakan Penerima <br>
        Bantuan Sosial Tunai
    </h1>
</div>
    
@endsection